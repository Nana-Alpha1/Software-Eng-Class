package com.cabrex.interactive_ui_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
